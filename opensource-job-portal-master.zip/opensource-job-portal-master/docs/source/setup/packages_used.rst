Django Packages Used
====================

.. class:: center

	Django==2.2.8

	arrow==0.12.1
	
	bpython==0.17.1
	
	behave-django==1.1.0
	
	celery==4.2.1
	
	coverage==4.5.1
	
	django-behave==0.1.6
	
	django-blog-it==0.3
	
	django-compressor==2.2
	
	django-celery-beat==1.2.0
	
	django-debug-toolbar==1.10.1
	
	django-endless-pagination==2.0
	
	django-debug-toolbar-template-timings==0.9
	
	django-haystack==2.8.1
	
	django-hmin==0.3.3
	
	django-tellme==0.6.5
	
	django-web-profiler==0.1.4
	
	elasticsearch==2.3
	
	google-api-python-client==1.7.4
	
	microurl==0.1.1
	
	prospector==1.1.4
	
	psycopg2-binary==2.7.5
	
	python-memcached==1.59
	
	pymongo==3.7.2
	
	raven==6.9.0
	
	redis==2.10.6
	
	sendgrid==5.6.0
	
	sorl-thumbnail==12.5.0
	
	tinys3==0.1.12
	
	twython==3.7.0
	
	beautifulsoup4==4.6.3
	
	utils==0.9.0
	
	python-magic==0.4.15
	
	jsonpickle==1.0
	
	pymemcache==2.0.0
	
	lxml==4.2.