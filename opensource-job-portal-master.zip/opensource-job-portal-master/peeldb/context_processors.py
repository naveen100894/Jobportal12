def get_pj_icons(request):
    logos = {
        "jobopenings": "http://cdn.peeljobs.com/jobopenings1.png",
        "logo": "https://cdn.peeljobs.com/logo.png",
        "favicon": "https://cdn.peeljobs.com/favicon.png",
        "cdn_path": "https://cdn.peeljobs.com/",
    }
    return logos
